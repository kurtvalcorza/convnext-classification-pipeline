"""Row 14 probes: tutorials/convnext_classification_colab.ipynb at the reviewed commit (826fde7).

CPU only (CUDA_VISIBLE_DEVICES=-1), install skipped via the notebook's DIMER_NOTEBOOK_CI_PREINSTALLED hook,
pinned build venv (torch 2.14.0, timm 1.0.29, numpy 2.5.3, pillow 11.3.0 = the notebook PINS), model snapshot
files hard-linked from a local copy and re-hashed by the notebook's own verify_snapshot (cell 7 writes the
manifest fresh). The tutorial dataset zip is fetched by cell 17 itself from its pinned Hugging Face URL.
google.colab.files.upload is replaced by a shim that returns prepared bytes (BYOD probes).
Usage: python run_probes.py <worktree> <weights_src> <workdir>
"""
import contextlib
import hashlib
import io
import json
import math
import os
import platform
import re
import sys
import time
import types
import zipfile
from pathlib import Path

WT, WSRC, WORK = (Path(a) for a in sys.argv[1:4])
NB = WT / "tutorials" / "convnext_classification_colab.ipynb"
RESULTS = {"env": {}, "static": {}, "cells": [], "probes": {}}
OUT = Path(__file__).with_name("results.json")


def save():
    OUT.write_text(json.dumps(RESULTS, indent=2, default=str), encoding="utf-8")


nb = json.loads(NB.read_text(encoding="utf-8"))
cells = nb["cells"]


def src(i):
    return "".join(cells[i]["source"])


code_idx = [i for i, c in enumerate(cells) if c["cell_type"] == "code"]

# ---- static
st = RESULTS["static"]
st["nbformat"] = [nb.get("nbformat"), nb.get("nbformat_minor")]
st["n_cells"], st["n_code"], st["code_idx"] = len(cells), len(code_idx), code_idx
st["metadata_dimer"] = nb["metadata"].get("dimer")
st["outputs_present"] = sum(len(c.get("outputs", [])) for c in cells if c["cell_type"] == "code")
compile_err = {}
for i in code_idx:
    try:
        compile(src(i), f"cell{i}", "exec")
    except SyntaxError as e:
        compile_err[i] = str(e)
st["compile_errors"] = compile_err
alltext = "\n".join(src(i) for i in range(len(cells)))
md = "\n".join(src(i) for i in range(len(cells)) if cells[i]["cell_type"] == "markdown")
st["todo_markers"] = re.findall(r"\b(TODO|TBD|FIXME|WRITE ME)\b", alltext)
st["pip_install_in_kernel"] = "'pip', 'install'" in src(3)
st["uses_uv"] = bool(re.search(r"\buv (venv|pip)\b", alltext))
st["restart_instruction_in_cell3"] = "Restart the runtime" in src(3)
st["cellView_form_cells"] = [i for i in code_idx if cells[i]["metadata"].get("cellView") == "form"]
st["guided_markers"] = {k: (k.lower() in md.lower()) for k in [
    "How to use this notebook", "Roadmap", "Glossary", "Predict", "Check your reasoning", "What to notice",
    "Expected result", "Troubleshooting", "conclusion", "audience", "Infrastructure", "re-run", "rerun"]}
st["look_for_count"] = len(re.findall(r"(?i)look for", md))
# names used in cell 17's fallback branch but defined nowhere in the notebook
defined = set(re.findall(r"^\s*([A-Z_][A-Z0-9_]*)\s*=", alltext, re.M))
st["fallback_names_undefined"] = [n for n in ("SAMPLE_HEIGHT", "SAMPLE_WIDTH") if n not in defined]
st["head_only_claims"] = [m for m in re.findall(r"[^.]*\bhead (?:fine-tuning|adaptation)[^.]*", md)][:4]
st["fit_optimizer_line"] = [ln.strip() for ln in src(5).splitlines() if "AdamW(" in ln]
st["verdict_success_hardcoded"] = "'verdict': 'success'" in src(19)
st["fine_tuned_pipe_uses"] = len(re.findall(r"\bfine_tuned_pipe\b", alltext))
st["prereq_nothing_downloaded_claim"] = "nothing is downloaded" in src(1)
st["fit_call_hyperparams_are_form_fields"] = bool(re.search(r"(EPOCHS|LEARNING_RATE|BATCH_SIZE)\s*=.*@param", src(17)))
st["validate_inputs_called_on_dataset"] = "validate_inputs" in src(17)
st["result_json_finetune_keys"] = re.findall(r"'fine_tuning': \{([^}]*)\}", src(21), re.S)
mod = (WT / "src/convnext_classification_pipeline/pipeline.py").read_text(encoding="utf-8").splitlines()
cell = src(5).splitlines()
st["carried_cell_5"] = {"module_lines": len(mod), "cell_lines": len(cell),
                        "differing_lines": sum(1 for a, b in zip(mod, cell) if a != b)}
save()

# ---- workspace
WORK.mkdir(parents=True, exist_ok=True)
os.chdir(WORK)
wdir = WORK / "weights" / "convnext-tiny-in12k"
wdir.mkdir(parents=True, exist_ok=True)
for name in ("README.md", "config.json", "model.safetensors"):
    target = wdir / name
    if not target.exists():
        os.link(WSRC / name, target)
os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"
os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"

UPLOADS = []  # queue of {name: bytes} dicts returned by the google.colab shim


def _upload():
    return UPLOADS.pop(0)


g = types.ModuleType("google")
gc = types.ModuleType("google.colab")
gcf = types.ModuleType("google.colab.files")
gcf.upload = _upload
gc.files = gcf
g.colab = gc
sys.modules.update({"google": g, "google.colab": gc, "google.colab.files": gcf})

ns = {"__name__": "__main__"}


def run_cell(i, source=None, label=None):
    buf = io.StringIO()
    t0 = time.time()
    rec = {"cell": i, "label": label or f"cell {i}"}
    try:
        with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
            exec(compile(source if source is not None else src(i), f"cell{i}", "exec"), ns)
        rec["status"] = "ok"
    except Exception as exc:  # noqa: BLE001
        rec["status"] = "error"
        rec["error"] = f"{type(exc).__name__}: {exc}"[:800]
    rec["seconds"] = round(time.time() - t0, 1)
    rec["stdout"] = buf.getvalue()[-2500:]
    RESULTS["cells"].append(rec)
    save()
    print(rec["label"], rec["status"], rec["seconds"], rec.get("error", ""), flush=True)
    return rec


def with_fields(i, **fields):
    s = src(i)
    for k, v in fields.items():
        s, n = re.subn(rf"^{k} = .*$", f"{k} = {v!r}", s, count=1, flags=re.M)
        assert n == 1, k
    return s


def wilson(k, n, z=1.96):
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return [round(c - h, 3), round(c + h, 3)]


# ---- P1 default path, every code cell in order, defaults unchanged
for i in code_idx:
    r = run_cell(i, label=f"P1 cell {i}")
    if r["status"] != "ok":
        break
P = RESULTS["probes"]
import torch  # noqa: E402
from PIL import Image  # noqa: E402

RESULTS["env"] = {"python": platform.python_version(), "torch": torch.__version__, "cuda": torch.cuda.is_available(),
                  "threads": torch.get_num_threads(), "executable": sys.executable, "platform": platform.platform()}
save()

# ---- P2 dataset facts (zip fetched by cell 17)
try:
    zb = ns["zip_bytes"]
    with zipfile.ZipFile(io.BytesIO(zb)) as z:
        imgs = [n for n in z.namelist() if n.lower().endswith((".png", ".jpg", ".jpeg"))]
        per = {}
        for n in imgs:
            per.setdefault(n.strip("/").split("/")[-2], 0)
            per[n.strip("/").split("/")[-2]] += 1
        size = Image.open(io.BytesIO(z.read(imgs[0]))).size
    P["P2_dataset"] = {"zip_bytes": len(zb), "sha256": hashlib.sha256(zb).hexdigest(), "images": len(imgs),
                       "per_class": per, "first_image_size": size, "train": len(ns["train_images"]),
                       "val": len(ns["val_images"]), "val_targets": ns["val_targets"]}
except Exception as exc:  # noqa: BLE001
    P["P2_dataset"] = {"error": repr(exc)}
save()

# ---- P3 reload equivalence (not done by the notebook) + which parameters changed (head-only claim)
try:
    ft, rl = ns["fine_tuned_pipe"], ns["reloaded_pipe"]
    diffs, same = [], 0
    for img in ns["val_images"]:
        a, b = ft.predict(img)["predictions"][0], rl.predict(img)["predictions"][0]
        same += a["predicted_index"] == b["predicted_index"]
        diffs.append(max(abs(x["score"] - y["score"]) for x, y in zip(a["top_k"], b["top_k"])))
    from safetensors.torch import load_file
    base = load_file(str(wdir / "model.safetensors"))
    tuned = load_file("outputs/convnext_classification_finetuned/model.safetensors")
    changed, total, changed_t, n_t = 0, 0, [], 0
    for k, v in tuned.items():
        if k in base and base[k].shape == v.shape and v.is_floating_point():
            n_t += 1
            total += v.numel()
            if not torch.equal(base[k], v):
                changed += v.numel()
                changed_t.append(k)
    P["P3_reload_and_params"] = {
        "in_memory_vs_reloaded_same_label": f"{same}/{len(diffs)}", "max_abs_score_diff": max(diffs),
        "shared_float_tensors": n_t, "tensors_changed": len(changed_t), "params_changed": changed,
        "params_shared_total": total, "example_changed": changed_t[:3],
        "head_keys_in_tuned": [k for k in tuned if k.startswith("head.fc")]}
    acc = ns["finetuned_eval_report"]["metrics"]["accuracy"]
    n = ns["finetuned_eval_report"]["validation_samples"]
    k = round(acc * n)
    P["P3_reload_and_params"]["val_accuracy"] = acc
    P["P3_reload_and_params"]["wilson95"] = wilson(k, n)
    P["P3_reload_and_params"]["verdict"] = ns["finetuned_eval_report"]["verdict"]
except Exception as exc:  # noqa: BLE001
    P["P3_reload_and_params"] = {"error": repr(exc)}
save()

# ---- P4 split-seed variability of the fine-tune evaluation (SEED is a plain variable in cell 17)
P["P4_seed_variability"] = []
for seed in (0, 1, 2):
    r1 = run_cell(17, with_fields(17, SEED=seed), label=f"P4 cell 17 SEED={seed}")
    r2 = run_cell(19, label=f"P4 cell 19 SEED={seed}") if r1["status"] == "ok" else {"status": "skipped"}
    if r2["status"] == "ok":
        m = ns["finetuned_eval_report"]["metrics"]
        P["P4_seed_variability"].append({"seed": seed, "accuracy": m["accuracy"],
                                         "baseline": m["majority_baseline_accuracy"],
                                         "train_loss": ns["train_meta"]["history"][0]["train_loss"],
                                         "verdict": ns["finetuned_eval_report"]["verdict"]})
    save()

ZB = ns.get("zip_bytes")
# ---- P5 air-gapped fallback branch ("gracefully falls back to deterministic synthetic stripes")
s17 = src(17).replace(ns["SAMPLE_DATASET_URL"], "http://127.0.0.1:9/unreachable.zip")
r = run_cell(17, s17, label="P5 cell 17 download unreachable")
P["P5_fallback"] = {"status": r["status"], "error": r.get("error"), "stdout_tail": r["stdout"][-400:]}
save()


# ---- P6 active learning: BYOD single image with a ground-truth index (Next experiments, first item)
def png_bytes(img, fmt="PNG"):
    b = io.BytesIO()
    img.save(b, format=fmt)
    return b.getvalue()


with zipfile.ZipFile(io.BytesIO(ZB)) as z:
    names = sorted(n for n in z.namelist() if n.lower().endswith(".png"))
    truck = [n for n in names if "/truck/" in n][0]
    frog = [n for n in names if "/frog/" in n][0]
    truck_img = Image.open(io.BytesIO(z.read(truck))).convert("RGB")
    frog_img = Image.open(io.BytesIO(z.read(frog))).convert("RGB")
UPLOADS.append({"truck.png": png_bytes(truck_img.resize((224, 224)))})
r9 = run_cell(9, with_fields(9, USE_BYOD=True, GROUND_TRUTH_INDEX=867), label="P6 cell 9 BYOD image gt=867")
for i in (11, 13, 15):
    run_cell(i, label=f"P6 cell {i}")
P["P6_byod_image"] = {"report_verdict": ns.get("report", {}).get("verdict"),
                      "metrics": ns.get("report", {}).get("metrics"),
                      "top1": ns.get("prediction", {}).get("predicted_label")}
r = run_cell(9, with_fields(9, GROUND_TRUTH_INDEX=1000), label="P6 cell 9 GROUND_TRUTH_INDEX=1000")
P["P6_byod_image"]["invalid_gt"] = r.get("error")
UPLOADS.append({"notes.png": b"this is text, not an image"})
r = run_cell(9, with_fields(9, USE_BYOD=True), label="P6 cell 9 BYOD text-as-png")
P["P6_byod_image"]["text_as_png"] = r.get("error")
save()


# ---- P7 BYOD dataset zips
def make_zip(entries):
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w") as z:
        for name, data in entries:
            z.writestr(name, data)
    return b.getvalue()


def drawn(color, i, size=(48, 48)):
    arr = Image.new("RGB", size, color)
    for x in range(0, size[0], 6 + i):
        for y in range(size[1]):
            arr.putpixel((x, y), (255, 255, 255))
    return png_bytes(arr)


ok_unsplit = make_zip([(f"ds/{c}/{j}.png", drawn(col, j)) for c, col in (("red", (200, 20, 20)), ("blue", (20, 20, 200)))
                       for j in range(5)])
cases = {
    "a_unsplit_ok": ok_unsplit,
    "b_trainval_val_class_missing_from_train": make_zip(
        [(f"train/{c}/{j}.png", drawn(col, j)) for c, col in (("red", (200, 20, 20)), ("blue", (20, 20, 200))) for j in range(3)]
        + [(f"val/{c}/{j}.png", drawn(col, j)) for c, col in (("red", (200, 20, 20)), ("green", (20, 200, 20))) for j in range(2)]),
    "c_root_level_images": make_zip([(f"{j}.png", drawn((200, 20, 20), j)) for j in range(3)]
                                    + [(f"blue/{j}.png", drawn((20, 20, 200), j)) for j in range(3)]),
    "d_one_class": make_zip([(f"red/{j}.png", drawn((200, 20, 20), j)) for j in range(4)]),
    "e_traversal": make_zip([("../evil/0.png", drawn((1, 1, 1), 0)), ("red/0.png", drawn((200, 20, 20), 0))]),
    "f_class_with_one_image": make_zip([(f"red/{j}.png", drawn((200, 20, 20), j)) for j in range(3)] + [("blue/0.png", drawn((20, 20, 200), 0))]),
    "g_oversized_image_in_val": make_zip([(f"red/{j}.png", drawn((200, 20, 20), j)) for j in range(3)]
                                         + [(f"wide/{j}.png", drawn((20, 200, 20), j, size=(4100, 8))) for j in range(2)]),
    "h_corrupt_image": make_zip([(f"red/{j}.png", drawn((200, 20, 20), j)) for j in range(2)] + [("blue/0.png", b"not an image"), ("blue/1.png", drawn((20, 20, 200), 1))]),
}
P["P7_byod_dataset"] = {}
s17b = with_fields(17, USE_BYOD_DATASET=True)
for name, data in cases.items():
    UPLOADS.append({f"{name}.zip": data})
    r = run_cell(17, s17b, label=f"P7 {name} cell 17")
    rec = {"cell17": r["status"], "error17": r.get("error")}
    if r["status"] == "ok":
        rec["classes"] = ns["CUSTOM_CLASSES"]
        rec["train"], rec["val"] = len(ns["train_images"]), len(ns["val_images"])
        r2 = run_cell(19, label=f"P7 {name} cell 19")
        rec["cell19"], rec["error19"] = r2["status"], r2.get("error")
        if r2["status"] == "ok":
            rec["accuracy"] = ns["finetuned_eval_report"]["metrics"]["accuracy"]
            rec["verdict"] = ns["finetuned_eval_report"]["verdict"]
    P["P7_byod_dataset"][name] = rec
    save()
UPLOADS.append({"data.tar": b"x"})
r = run_cell(17, s17b, label="P7 i_not_zip cell 17")
P["P7_byod_dataset"]["i_not_zip"] = {"cell17": r["status"], "error17": r.get("error")}
save()
print("done", flush=True)
